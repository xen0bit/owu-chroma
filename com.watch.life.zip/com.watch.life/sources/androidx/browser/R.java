package androidx.browser;

/* loaded from: classes.dex */
public final class R {

    public static final class color {
        public static final int browser_actions_bg_grey = 0x7f060040;
        public static final int browser_actions_divider_color = 0x7f060041;
        public static final int browser_actions_text_color = 0x7f060042;
        public static final int browser_actions_title_color = 0x7f060043;

        private color() {
        }
    }

    public static final class dimen {
        public static final int browser_actions_context_menu_max_width = 0x7f070062;
        public static final int browser_actions_context_menu_min_padding = 0x7f070063;

        private dimen() {
        }
    }

    public static final class id {
        public static final int browser_actions_header_text = 0x7f0a017a;
        public static final int browser_actions_menu_item_icon = 0x7f0a017b;
        public static final int browser_actions_menu_item_text = 0x7f0a017c;
        public static final int browser_actions_menu_items = 0x7f0a017d;
        public static final int browser_actions_menu_view = 0x7f0a017e;

        private id() {
        }
    }

    public static final class layout {
        public static final int browser_actions_context_menu_page = 0x7f0d0244;
        public static final int browser_actions_context_menu_row = 0x7f0d0245;

        private layout() {
        }
    }

    public static final class string {
        public static final int copy_toast_msg = 0x7f130115;
        public static final int fallback_menu_item_copy_link = 0x7f130367;
        public static final int fallback_menu_item_open_in_browser = 0x7f130368;
        public static final int fallback_menu_item_share_link = 0x7f130369;

        private string() {
        }
    }

    public static final class xml {
        public static final int image_share_filepaths = 0x7f160004;

        private xml() {
        }
    }

    private R() {
    }
}
