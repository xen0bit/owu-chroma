package androidx.cardview;

/* loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static final int cardBackgroundColor = 0x7f0401d8;
        public static final int cardCornerRadius = 0x7f0401d9;
        public static final int cardElevation = 0x7f0401da;
        public static final int cardMaxElevation = 0x7f0401dd;
        public static final int cardPreventCornerOverlap = 0x7f0401de;
        public static final int cardUseCompatPadding = 0x7f0401e0;
        public static final int cardViewStyle = 0x7f0401e1;
        public static final int contentPadding = 0x7f0402fc;
        public static final int contentPaddingBottom = 0x7f0402fd;
        public static final int contentPaddingLeft = 0x7f0402ff;
        public static final int contentPaddingRight = 0x7f040300;
        public static final int contentPaddingTop = 0x7f040302;

        private attr() {
        }
    }

    public static final class color {
        public static final int cardview_dark_background = 0x7f06004a;
        public static final int cardview_light_background = 0x7f06004b;
        public static final int cardview_shadow_end_color = 0x7f06004c;
        public static final int cardview_shadow_start_color = 0x7f06004d;

        private color() {
        }
    }

    public static final class dimen {
        public static final int cardview_compat_inset_shadow = 0x7f070064;
        public static final int cardview_default_elevation = 0x7f070065;
        public static final int cardview_default_radius = 0x7f070066;

        private dimen() {
        }
    }

    public static final class style {
        public static final int Base_CardView = 0x7f140019;
        public static final int CardView = 0x7f14012c;
        public static final int CardView_Dark = 0x7f14012d;
        public static final int CardView_Light = 0x7f14012e;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] CardView = {android.R.attr.minWidth, android.R.attr.minHeight, com.watch.life.R.attr.cardBackgroundColor, com.watch.life.R.attr.cardCornerRadius, com.watch.life.R.attr.cardElevation, com.watch.life.R.attr.cardMaxElevation, com.watch.life.R.attr.cardPreventCornerOverlap, com.watch.life.R.attr.cardUseCompatPadding, com.watch.life.R.attr.contentPadding, com.watch.life.R.attr.contentPaddingBottom, com.watch.life.R.attr.contentPaddingLeft, com.watch.life.R.attr.contentPaddingRight, com.watch.life.R.attr.contentPaddingTop};
        public static final int CardView_android_minHeight = 0x00000001;
        public static final int CardView_android_minWidth = 0x00000000;
        public static final int CardView_cardBackgroundColor = 0x00000002;
        public static final int CardView_cardCornerRadius = 0x00000003;
        public static final int CardView_cardElevation = 0x00000004;
        public static final int CardView_cardMaxElevation = 0x00000005;
        public static final int CardView_cardPreventCornerOverlap = 0x00000006;
        public static final int CardView_cardUseCompatPadding = 0x00000007;
        public static final int CardView_contentPadding = 0x00000008;
        public static final int CardView_contentPaddingBottom = 0x00000009;
        public static final int CardView_contentPaddingLeft = 0x0000000a;
        public static final int CardView_contentPaddingRight = 0x0000000b;
        public static final int CardView_contentPaddingTop = 0x0000000c;

        private styleable() {
        }
    }

    private R() {
    }
}
