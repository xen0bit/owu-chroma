package androidx.constraintlayout.motion.widget;

/* loaded from: classes.dex */
public interface FloatLayout {
    void layout(float f2, float f3, float f4, float f5);
}
