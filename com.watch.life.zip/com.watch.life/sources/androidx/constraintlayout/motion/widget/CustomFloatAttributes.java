package androidx.constraintlayout.motion.widget;

/* loaded from: classes.dex */
public interface CustomFloatAttributes {
    float get(String str);

    String[] getListOfAttributes();

    void set(String str, float f2);
}
