package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class ChainRun extends WidgetRun {
    private int mChainStyle;
    ArrayList<WidgetRun> mWidgets;

    public ChainRun(ConstraintWidget constraintWidget, int i2) {
        super(constraintWidget);
        this.mWidgets = new ArrayList<>();
        this.orientation = i2;
        build();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ChainRun ");
        sb.append(this.orientation == 0 ? "horizontal : " : "vertical : ");
        Iterator<WidgetRun> it = this.mWidgets.iterator();
        while (it.hasNext()) {
            WidgetRun next = it.next();
            sb.append("<");
            sb.append(next);
            sb.append("> ");
        }
        return sb.toString();
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun
    boolean supportsWrapComputation() {
        int size = this.mWidgets.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!this.mWidgets.get(i2).supportsWrapComputation()) {
                return false;
            }
        }
        return true;
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun
    public long getWrapDimension() {
        int size = this.mWidgets.size();
        long wrapDimension = 0;
        for (int i2 = 0; i2 < size; i2++) {
            wrapDimension = wrapDimension + r4.start.mMargin + this.mWidgets.get(i2).getWrapDimension() + r4.end.mMargin;
        }
        return wrapDimension;
    }

    private void build() {
        ConstraintWidget constraintWidget;
        ConstraintWidget constraintWidget2 = this.mWidget;
        ConstraintWidget previousChainMember = constraintWidget2.getPreviousChainMember(this.orientation);
        while (true) {
            ConstraintWidget constraintWidget3 = previousChainMember;
            constraintWidget = constraintWidget2;
            constraintWidget2 = constraintWidget3;
            if (constraintWidget2 == null) {
                break;
            } else {
                previousChainMember = constraintWidget2.getPreviousChainMember(this.orientation);
            }
        }
        this.mWidget = constraintWidget;
        this.mWidgets.add(constraintWidget.getRun(this.orientation));
        ConstraintWidget nextChainMember = constraintWidget.getNextChainMember(this.orientation);
        while (nextChainMember != null) {
            this.mWidgets.add(nextChainMember.getRun(this.orientation));
            nextChainMember = nextChainMember.getNextChainMember(this.orientation);
        }
        Iterator<WidgetRun> it = this.mWidgets.iterator();
        while (it.hasNext()) {
            WidgetRun next = it.next();
            if (this.orientation == 0) {
                next.mWidget.horizontalChainRun = this;
            } else if (this.orientation == 1) {
                next.mWidget.verticalChainRun = this;
            }
        }
        if (this.orientation == 0 && ((ConstraintWidgetContainer) this.mWidget.getParent()).isRtl() && this.mWidgets.size() > 1) {
            ArrayList<WidgetRun> arrayList = this.mWidgets;
            this.mWidget = arrayList.get(arrayList.size() - 1).mWidget;
        }
        this.mChainStyle = this.orientation == 0 ? this.mWidget.getHorizontalChainStyle() : this.mWidget.getVerticalChainStyle();
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun
    void clear() {
        this.mRunGroup = null;
        Iterator<WidgetRun> it = this.mWidgets.iterator();
        while (it.hasNext()) {
            it.next().clear();
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun
    void reset() {
        this.start.resolved = false;
        this.end.resolved = false;
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun, androidx.constraintlayout.core.widgets.analyzer.Dependency
    public void update(Dependency dependency) {
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        float f2;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        float f3;
        int i12;
        int i13;
        int i14;
        if (this.start.resolved && this.end.resolved) {
            ConstraintWidget parent = this.mWidget.getParent();
            boolean zIsRtl = parent instanceof ConstraintWidgetContainer ? ((ConstraintWidgetContainer) parent).isRtl() : false;
            int i15 = this.end.value - this.start.value;
            int size = this.mWidgets.size();
            int i16 = 0;
            while (true) {
                i2 = -1;
                i3 = 8;
                if (i16 >= size) {
                    i16 = -1;
                    break;
                } else if (this.mWidgets.get(i16).mWidget.getVisibility() != 8) {
                    break;
                } else {
                    i16++;
                }
            }
            int i17 = size - 1;
            int i18 = i17;
            while (true) {
                if (i18 < 0) {
                    break;
                }
                if (this.mWidgets.get(i18).mWidget.getVisibility() != 8) {
                    i2 = i18;
                    break;
                }
                i18--;
            }
            int i19 = 0;
            while (i19 < 2) {
                int i20 = 0;
                i5 = 0;
                i6 = 0;
                int i21 = 0;
                f2 = 0.0f;
                while (i20 < size) {
                    WidgetRun widgetRun = this.mWidgets.get(i20);
                    if (widgetRun.mWidget.getVisibility() != i3) {
                        i21++;
                        if (i20 > 0 && i20 >= i16) {
                            i5 += widgetRun.start.mMargin;
                        }
                        int i22 = widgetRun.mDimension.value;
                        boolean z = widgetRun.mDimensionBehavior != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                        if (z) {
                            if (this.orientation == 0 && !widgetRun.mWidget.mHorizontalRun.mDimension.resolved) {
                                return;
                            }
                            if (this.orientation == 1 && !widgetRun.mWidget.mVerticalRun.mDimension.resolved) {
                                return;
                            }
                        } else {
                            if (widgetRun.matchConstraintsType == 1 && i19 == 0) {
                                i22 = widgetRun.mDimension.wrapValue;
                                i6++;
                            } else if (widgetRun.mDimension.resolved) {
                            }
                            z = true;
                        }
                        if (z) {
                            i5 += i22;
                        } else {
                            i6++;
                            float f4 = widgetRun.mWidget.mWeight[this.orientation];
                            if (f4 >= 0.0f) {
                                f2 += f4;
                            }
                        }
                        if (i20 < i17 && i20 < i2) {
                            i5 += -widgetRun.end.mMargin;
                        }
                    }
                    i20++;
                    i3 = 8;
                }
                if (i5 < i15 || i6 == 0) {
                    i4 = i21;
                    break;
                } else {
                    i19++;
                    i3 = 8;
                }
            }
            i4 = 0;
            i5 = 0;
            i6 = 0;
            f2 = 0.0f;
            int i23 = this.start.value;
            if (zIsRtl) {
                i23 = this.end.value;
            }
            if (i5 > i15) {
                i23 = zIsRtl ? i23 + ((int) (((i5 - i15) / 2.0f) + 0.5f)) : i23 - ((int) (((i5 - i15) / 2.0f) + 0.5f));
            }
            if (i6 > 0) {
                float f5 = i15 - i5;
                int i24 = (int) ((f5 / i6) + 0.5f);
                int i25 = 0;
                int i26 = 0;
                while (i25 < size) {
                    WidgetRun widgetRun2 = this.mWidgets.get(i25);
                    int i27 = i24;
                    if (widgetRun2.mWidget.getVisibility() == 8 || widgetRun2.mDimensionBehavior != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || widgetRun2.mDimension.resolved) {
                        i11 = i23;
                        f3 = f5;
                        i12 = i5;
                    } else {
                        int i28 = f2 > 0.0f ? (int) (((widgetRun2.mWidget.mWeight[this.orientation] * f5) / f2) + 0.5f) : i27;
                        if (this.orientation == 0) {
                            i13 = widgetRun2.mWidget.mMatchConstraintMaxWidth;
                            f3 = f5;
                            i14 = widgetRun2.mWidget.mMatchConstraintMinWidth;
                        } else {
                            f3 = f5;
                            i13 = widgetRun2.mWidget.mMatchConstraintMaxHeight;
                            i14 = widgetRun2.mWidget.mMatchConstraintMinHeight;
                        }
                        i12 = i5;
                        i11 = i23;
                        int iMax = Math.max(i14, widgetRun2.matchConstraintsType == 1 ? Math.min(i28, widgetRun2.mDimension.wrapValue) : i28);
                        if (i13 > 0) {
                            iMax = Math.min(i13, iMax);
                        }
                        if (iMax != i28) {
                            i26++;
                            i28 = iMax;
                        }
                        widgetRun2.mDimension.resolve(i28);
                    }
                    i25++;
                    i24 = i27;
                    f5 = f3;
                    i5 = i12;
                    i23 = i11;
                }
                i7 = i23;
                int i29 = i5;
                if (i26 > 0) {
                    i6 -= i26;
                    int i30 = 0;
                    for (int i31 = 0; i31 < size; i31++) {
                        WidgetRun widgetRun3 = this.mWidgets.get(i31);
                        if (widgetRun3.mWidget.getVisibility() != 8) {
                            if (i31 > 0 && i31 >= i16) {
                                i30 += widgetRun3.start.mMargin;
                            }
                            i30 += widgetRun3.mDimension.value;
                            if (i31 < i17 && i31 < i2) {
                                i30 += -widgetRun3.end.mMargin;
                            }
                        }
                    }
                    i5 = i30;
                } else {
                    i5 = i29;
                }
                i9 = 2;
                if (this.mChainStyle == 2 && i26 == 0) {
                    i8 = 0;
                    this.mChainStyle = 0;
                } else {
                    i8 = 0;
                }
            } else {
                i7 = i23;
                i8 = 0;
                i9 = 2;
            }
            if (i5 > i15) {
                this.mChainStyle = i9;
            }
            if (i4 > 0 && i6 == 0 && i16 == i2) {
                this.mChainStyle = i9;
            }
            int i32 = this.mChainStyle;
            if (i32 == 1) {
                if (i4 > 1) {
                    i10 = (i15 - i5) / (i4 - 1);
                } else {
                    i10 = i4 == 1 ? (i15 - i5) / 2 : i8;
                }
                if (i6 > 0) {
                    i10 = i8;
                }
                int i33 = i7;
                for (int i34 = i8; i34 < size; i34++) {
                    WidgetRun widgetRun4 = this.mWidgets.get(zIsRtl ? size - (i34 + 1) : i34);
                    if (widgetRun4.mWidget.getVisibility() == 8) {
                        widgetRun4.start.resolve(i33);
                        widgetRun4.end.resolve(i33);
                    } else {
                        if (i34 > 0) {
                            i33 = zIsRtl ? i33 - i10 : i33 + i10;
                        }
                        if (i34 > 0 && i34 >= i16) {
                            if (zIsRtl) {
                                i33 -= widgetRun4.start.mMargin;
                            } else {
                                i33 += widgetRun4.start.mMargin;
                            }
                        }
                        if (zIsRtl) {
                            widgetRun4.end.resolve(i33);
                        } else {
                            widgetRun4.start.resolve(i33);
                        }
                        int i35 = widgetRun4.mDimension.value;
                        if (widgetRun4.mDimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widgetRun4.matchConstraintsType == 1) {
                            i35 = widgetRun4.mDimension.wrapValue;
                        }
                        i33 = zIsRtl ? i33 - i35 : i33 + i35;
                        if (zIsRtl) {
                            widgetRun4.start.resolve(i33);
                        } else {
                            widgetRun4.end.resolve(i33);
                        }
                        widgetRun4.mResolved = true;
                        if (i34 < i17 && i34 < i2) {
                            if (zIsRtl) {
                                i33 -= -widgetRun4.end.mMargin;
                            } else {
                                i33 += -widgetRun4.end.mMargin;
                            }
                        }
                    }
                }
                return;
            }
            if (i32 == 0) {
                int i36 = (i15 - i5) / (i4 + 1);
                if (i6 > 0) {
                    i36 = i8;
                }
                int i37 = i7;
                for (int i38 = i8; i38 < size; i38++) {
                    WidgetRun widgetRun5 = this.mWidgets.get(zIsRtl ? size - (i38 + 1) : i38);
                    if (widgetRun5.mWidget.getVisibility() == 8) {
                        widgetRun5.start.resolve(i37);
                        widgetRun5.end.resolve(i37);
                    } else {
                        int i39 = zIsRtl ? i37 - i36 : i37 + i36;
                        if (i38 > 0 && i38 >= i16) {
                            if (zIsRtl) {
                                i39 -= widgetRun5.start.mMargin;
                            } else {
                                i39 += widgetRun5.start.mMargin;
                            }
                        }
                        if (zIsRtl) {
                            widgetRun5.end.resolve(i39);
                        } else {
                            widgetRun5.start.resolve(i39);
                        }
                        int iMin = widgetRun5.mDimension.value;
                        if (widgetRun5.mDimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widgetRun5.matchConstraintsType == 1) {
                            iMin = Math.min(iMin, widgetRun5.mDimension.wrapValue);
                        }
                        i37 = zIsRtl ? i39 - iMin : i39 + iMin;
                        if (zIsRtl) {
                            widgetRun5.start.resolve(i37);
                        } else {
                            widgetRun5.end.resolve(i37);
                        }
                        if (i38 < i17 && i38 < i2) {
                            if (zIsRtl) {
                                i37 -= -widgetRun5.end.mMargin;
                            } else {
                                i37 += -widgetRun5.end.mMargin;
                            }
                        }
                    }
                }
                return;
            }
            if (i32 == 2) {
                float horizontalBiasPercent = this.orientation == 0 ? this.mWidget.getHorizontalBiasPercent() : this.mWidget.getVerticalBiasPercent();
                if (zIsRtl) {
                    horizontalBiasPercent = 1.0f - horizontalBiasPercent;
                }
                int i40 = (int) (((i15 - i5) * horizontalBiasPercent) + 0.5f);
                if (i40 < 0 || i6 > 0) {
                    i40 = i8;
                }
                int i41 = zIsRtl ? i7 - i40 : i7 + i40;
                for (int i42 = i8; i42 < size; i42++) {
                    WidgetRun widgetRun6 = this.mWidgets.get(zIsRtl ? size - (i42 + 1) : i42);
                    if (widgetRun6.mWidget.getVisibility() == 8) {
                        widgetRun6.start.resolve(i41);
                        widgetRun6.end.resolve(i41);
                    } else {
                        if (i42 > 0 && i42 >= i16) {
                            if (zIsRtl) {
                                i41 -= widgetRun6.start.mMargin;
                            } else {
                                i41 += widgetRun6.start.mMargin;
                            }
                        }
                        if (zIsRtl) {
                            widgetRun6.end.resolve(i41);
                        } else {
                            widgetRun6.start.resolve(i41);
                        }
                        int i43 = widgetRun6.mDimension.value;
                        if (widgetRun6.mDimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widgetRun6.matchConstraintsType == 1) {
                            i43 = widgetRun6.mDimension.wrapValue;
                        }
                        i41 = zIsRtl ? i41 - i43 : i41 + i43;
                        if (zIsRtl) {
                            widgetRun6.start.resolve(i41);
                        } else {
                            widgetRun6.end.resolve(i41);
                        }
                        if (i42 < i17 && i42 < i2) {
                            if (zIsRtl) {
                                i41 -= -widgetRun6.end.mMargin;
                            } else {
                                i41 += -widgetRun6.end.mMargin;
                            }
                        }
                    }
                }
            }
        }
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun
    public void applyToWidget() {
        for (int i2 = 0; i2 < this.mWidgets.size(); i2++) {
            this.mWidgets.get(i2).applyToWidget();
        }
    }

    private ConstraintWidget getFirstVisibleWidget() {
        for (int i2 = 0; i2 < this.mWidgets.size(); i2++) {
            WidgetRun widgetRun = this.mWidgets.get(i2);
            if (widgetRun.mWidget.getVisibility() != 8) {
                return widgetRun.mWidget;
            }
        }
        return null;
    }

    private ConstraintWidget getLastVisibleWidget() {
        for (int size = this.mWidgets.size() - 1; size >= 0; size--) {
            WidgetRun widgetRun = this.mWidgets.get(size);
            if (widgetRun.mWidget.getVisibility() != 8) {
                return widgetRun.mWidget;
            }
        }
        return null;
    }

    @Override // androidx.constraintlayout.core.widgets.analyzer.WidgetRun
    void apply() {
        Iterator<WidgetRun> it = this.mWidgets.iterator();
        while (it.hasNext()) {
            it.next().apply();
        }
        int size = this.mWidgets.size();
        if (size < 1) {
            return;
        }
        ConstraintWidget constraintWidget = this.mWidgets.get(0).mWidget;
        ConstraintWidget constraintWidget2 = this.mWidgets.get(size - 1).mWidget;
        if (this.orientation == 0) {
            ConstraintAnchor constraintAnchor = constraintWidget.mLeft;
            ConstraintAnchor constraintAnchor2 = constraintWidget2.mRight;
            DependencyNode target = getTarget(constraintAnchor, 0);
            int margin = constraintAnchor.getMargin();
            ConstraintWidget firstVisibleWidget = getFirstVisibleWidget();
            if (firstVisibleWidget != null) {
                margin = firstVisibleWidget.mLeft.getMargin();
            }
            if (target != null) {
                addTarget(this.start, target, margin);
            }
            DependencyNode target2 = getTarget(constraintAnchor2, 0);
            int margin2 = constraintAnchor2.getMargin();
            ConstraintWidget lastVisibleWidget = getLastVisibleWidget();
            if (lastVisibleWidget != null) {
                margin2 = lastVisibleWidget.mRight.getMargin();
            }
            if (target2 != null) {
                addTarget(this.end, target2, -margin2);
            }
        } else {
            ConstraintAnchor constraintAnchor3 = constraintWidget.mTop;
            ConstraintAnchor constraintAnchor4 = constraintWidget2.mBottom;
            DependencyNode target3 = getTarget(constraintAnchor3, 1);
            int margin3 = constraintAnchor3.getMargin();
            ConstraintWidget firstVisibleWidget2 = getFirstVisibleWidget();
            if (firstVisibleWidget2 != null) {
                margin3 = firstVisibleWidget2.mTop.getMargin();
            }
            if (target3 != null) {
                addTarget(this.start, target3, margin3);
            }
            DependencyNode target4 = getTarget(constraintAnchor4, 1);
            int margin4 = constraintAnchor4.getMargin();
            ConstraintWidget lastVisibleWidget2 = getLastVisibleWidget();
            if (lastVisibleWidget2 != null) {
                margin4 = lastVisibleWidget2.mBottom.getMargin();
            }
            if (target4 != null) {
                addTarget(this.end, target4, -margin4);
            }
        }
        this.start.updateDelegate = this;
        this.end.updateDelegate = this;
    }
}
