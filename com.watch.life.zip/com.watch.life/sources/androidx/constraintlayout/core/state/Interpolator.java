package androidx.constraintlayout.core.state;

/* loaded from: classes.dex */
public interface Interpolator {
    float getInterpolation(float f2);
}
