package androidx.constraintlayout.core.state;

/* loaded from: classes.dex */
public interface CorePixelDp {
    float toPixels(float f2);
}
