package androidx.appcompat.view.menu;

import androidx.appcompat.view.menu.MenuPresenter;

/* loaded from: classes.dex */
interface MenuHelper {
    void dismiss();

    void setPresenterCallback(MenuPresenter.Callback callback);
}
