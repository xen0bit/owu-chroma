package androidx.appcompat.view;

@Deprecated
/* loaded from: classes.dex */
public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
