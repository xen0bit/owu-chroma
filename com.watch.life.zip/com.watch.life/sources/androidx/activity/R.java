package androidx.activity;

/* loaded from: classes.dex */
public final class R {

    public static final class id {
        public static final int report_drawn = 0x7f0a13a5;
        public static final int view_tree_on_back_pressed_dispatcher_owner = 0x7f0a200a;

        private id() {
        }
    }

    private R() {
    }
}
